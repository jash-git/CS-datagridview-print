namespace XmlStoreClient
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctlTableDGV = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ctlFile_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFileNewMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFileOpenMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFileSaveMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFileSaveAsMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlFilePrintPreviewMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFilePrintMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFilePrintScreenshotMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlFileExitMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlRecord_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlRecordAddMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlRecordDeleteMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlRecordUpdateMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlCrypto_MNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlCryptoPasswordMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFieldEncryptMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlEncryptFieldMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlEncryptColumnMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlEncryptRowMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlEncryptTableMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlFieldDecryptMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlDecryptFieldMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlDecryptColumnMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlDecryptRowMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlDecryptTableMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlHelpAboutMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.ctlFilePrintDgvControlMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlPrintHowMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlPrintHowEverythingMNU = new System.Windows.Forms.ToolStripMenuItem();
            this.ctlPrintHowSelectedColumnMNU = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.ctlTableDGV)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctlTableDGV
            // 
            this.ctlTableDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ctlTableDGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlTableDGV.Location = new System.Drawing.Point(0, 24);
            this.ctlTableDGV.Name = "ctlTableDGV";
            this.ctlTableDGV.Size = new System.Drawing.Size(614, 419);
            this.ctlTableDGV.TabIndex = 0;
            this.ctlTableDGV.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OnMouseDown_DataGridView);
            this.ctlTableDGV.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.OnCellEditBegin);
            this.ctlTableDGV.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.OnRowsAdded);
            this.ctlTableDGV.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.OnCellEndEdit);
            this.ctlTableDGV.CurrentCellChanged += new System.EventHandler(this.OnCellChanged);
            this.ctlTableDGV.EditModeChanged += new System.EventHandler(this.OnEditModeChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFile_MNU,
            this.ctlRecord_MNU,
            this.ctlCrypto_MNU,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(614, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ctlFile_MNU
            // 
            this.ctlFile_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlFileNewMNU,
            this.ctlFileOpenMNU,
            this.ctlFileSaveMNU,
            this.ctlFileSaveAsMNU,
            this.toolStripMenuItem2,
            this.ctlPrintHowMNU,
            this.ctlFilePrintPreviewMNU,
            this.ctlFilePrintMNU,
            this.toolStripMenuItem3,
            this.ctlFilePrintScreenshotMNU,
            this.ctlFilePrintDgvControlMNU,
            this.toolStripMenuItem1,
            this.ctlFileExitMNU});
            this.ctlFile_MNU.Name = "ctlFile_MNU";
            this.ctlFile_MNU.Size = new System.Drawing.Size(35, 20);
            this.ctlFile_MNU.Text = "&File";
            // 
            // ctlFileNewMNU
            // 
            this.ctlFileNewMNU.Name = "ctlFileNewMNU";
            this.ctlFileNewMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFileNewMNU.Text = "&New";
            this.ctlFileNewMNU.Click += new System.EventHandler(this.ctlFileNewMNU_Click);
            // 
            // ctlFileOpenMNU
            // 
            this.ctlFileOpenMNU.Name = "ctlFileOpenMNU";
            this.ctlFileOpenMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFileOpenMNU.Text = "&Open ...";
            this.ctlFileOpenMNU.Click += new System.EventHandler(this.ctlFileOpenMNU_Click);
            // 
            // ctlFileSaveMNU
            // 
            this.ctlFileSaveMNU.Name = "ctlFileSaveMNU";
            this.ctlFileSaveMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFileSaveMNU.Text = "&Save";
            this.ctlFileSaveMNU.Click += new System.EventHandler(this.ctlFileSaveMNU_Click);
            // 
            // ctlFileSaveAsMNU
            // 
            this.ctlFileSaveAsMNU.Name = "ctlFileSaveAsMNU";
            this.ctlFileSaveAsMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFileSaveAsMNU.Text = "Save &As ...";
            this.ctlFileSaveAsMNU.Click += new System.EventHandler(this.ctlFileSaveAsMNU_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(191, 6);
            // 
            // ctlFilePrintPreviewMNU
            // 
            this.ctlFilePrintPreviewMNU.Name = "ctlFilePrintPreviewMNU";
            this.ctlFilePrintPreviewMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFilePrintPreviewMNU.Text = "Print Pre&view";
            this.ctlFilePrintPreviewMNU.Click += new System.EventHandler(this.ctlFilePrintPreviewMNU_Click);
            // 
            // ctlFilePrintMNU
            // 
            this.ctlFilePrintMNU.Name = "ctlFilePrintMNU";
            this.ctlFilePrintMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFilePrintMNU.Text = "&Print ...";
            this.ctlFilePrintMNU.Click += new System.EventHandler(this.ctlFilePrintMNU_Click);
            // 
            // ctlFilePrintScreenshotMNU
            // 
            this.ctlFilePrintScreenshotMNU.Name = "ctlFilePrintScreenshotMNU";
            this.ctlFilePrintScreenshotMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFilePrintScreenshotMNU.Text = "Print ScreenShot";
            this.ctlFilePrintScreenshotMNU.Click += new System.EventHandler(this.ctlFilePrintScreenshotMNU_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(191, 6);
            // 
            // ctlFileExitMNU
            // 
            this.ctlFileExitMNU.Name = "ctlFileExitMNU";
            this.ctlFileExitMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlFileExitMNU.Text = "E&xit";
            this.ctlFileExitMNU.Click += new System.EventHandler(this.ctlFileExitMNU_Click);
            // 
            // ctlRecord_MNU
            // 
            this.ctlRecord_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlRecordAddMNU,
            this.ctlRecordDeleteMNU,
            this.ctlRecordUpdateMNU});
            this.ctlRecord_MNU.Name = "ctlRecord_MNU";
            this.ctlRecord_MNU.Size = new System.Drawing.Size(53, 20);
            this.ctlRecord_MNU.Text = "&Record";
            // 
            // ctlRecordAddMNU
            // 
            this.ctlRecordAddMNU.Name = "ctlRecordAddMNU";
            this.ctlRecordAddMNU.Size = new System.Drawing.Size(124, 22);
            this.ctlRecordAddMNU.Text = "&Add";
            this.ctlRecordAddMNU.Click += new System.EventHandler(this.ctlRecordAddMNU_Click);
            // 
            // ctlRecordDeleteMNU
            // 
            this.ctlRecordDeleteMNU.Name = "ctlRecordDeleteMNU";
            this.ctlRecordDeleteMNU.Size = new System.Drawing.Size(124, 22);
            this.ctlRecordDeleteMNU.Text = "&Remove";
            this.ctlRecordDeleteMNU.Click += new System.EventHandler(this.ctlRecordDeleteMNU_Click);
            // 
            // ctlRecordUpdateMNU
            // 
            this.ctlRecordUpdateMNU.Name = "ctlRecordUpdateMNU";
            this.ctlRecordUpdateMNU.Size = new System.Drawing.Size(124, 22);
            this.ctlRecordUpdateMNU.Text = "&Update";
            this.ctlRecordUpdateMNU.Click += new System.EventHandler(this.ctlRecordUpdateMNU_Click);
            // 
            // ctlCrypto_MNU
            // 
            this.ctlCrypto_MNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlCryptoPasswordMNU,
            this.ctlFieldEncryptMNU,
            this.ctlFieldDecryptMNU});
            this.ctlCrypto_MNU.Name = "ctlCrypto_MNU";
            this.ctlCrypto_MNU.Size = new System.Drawing.Size(52, 20);
            this.ctlCrypto_MNU.Text = "&Crypto";
            // 
            // ctlCryptoPasswordMNU
            // 
            this.ctlCryptoPasswordMNU.Name = "ctlCryptoPasswordMNU";
            this.ctlCryptoPasswordMNU.Size = new System.Drawing.Size(183, 22);
            this.ctlCryptoPasswordMNU.Text = "&Password";
            this.ctlCryptoPasswordMNU.Click += new System.EventHandler(this.ctlFieldPasswordMNU_Click);
            // 
            // ctlFieldEncryptMNU
            // 
            this.ctlFieldEncryptMNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlEncryptFieldMNU,
            this.ctlEncryptColumnMNU,
            this.ctlEncryptRowMNU,
            this.ctlEncryptTableMNU});
            this.ctlFieldEncryptMNU.Name = "ctlFieldEncryptMNU";
            this.ctlFieldEncryptMNU.Size = new System.Drawing.Size(183, 22);
            this.ctlFieldEncryptMNU.Text = "Encrypt Current Cell";
            // 
            // ctlEncryptFieldMNU
            // 
            this.ctlEncryptFieldMNU.Name = "ctlEncryptFieldMNU";
            this.ctlEncryptFieldMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlEncryptFieldMNU.Text = "Current &Field";
            this.ctlEncryptFieldMNU.Click += new System.EventHandler(this.ctlEncryptFieldMNU_Click);
            // 
            // ctlEncryptColumnMNU
            // 
            this.ctlEncryptColumnMNU.Name = "ctlEncryptColumnMNU";
            this.ctlEncryptColumnMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlEncryptColumnMNU.Text = "Current &Column";
            this.ctlEncryptColumnMNU.Click += new System.EventHandler(this.ctlEncryptColumnMNU_Click);
            // 
            // ctlEncryptRowMNU
            // 
            this.ctlEncryptRowMNU.Name = "ctlEncryptRowMNU";
            this.ctlEncryptRowMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlEncryptRowMNU.Text = "Current &Row";
            this.ctlEncryptRowMNU.Click += new System.EventHandler(this.ctlEncryptRowMNU_Click);
            // 
            // ctlEncryptTableMNU
            // 
            this.ctlEncryptTableMNU.Name = "ctlEncryptTableMNU";
            this.ctlEncryptTableMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlEncryptTableMNU.Text = "Current &Table";
            this.ctlEncryptTableMNU.Click += new System.EventHandler(this.ctlEncryptTableMNU_Click);
            // 
            // ctlFieldDecryptMNU
            // 
            this.ctlFieldDecryptMNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlDecryptFieldMNU,
            this.ctlDecryptColumnMNU,
            this.ctlDecryptRowMNU,
            this.ctlDecryptTableMNU});
            this.ctlFieldDecryptMNU.Name = "ctlFieldDecryptMNU";
            this.ctlFieldDecryptMNU.Size = new System.Drawing.Size(183, 22);
            this.ctlFieldDecryptMNU.Text = "Decrypt Current Cell";
            // 
            // ctlDecryptFieldMNU
            // 
            this.ctlDecryptFieldMNU.Name = "ctlDecryptFieldMNU";
            this.ctlDecryptFieldMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlDecryptFieldMNU.Text = "Current &Field";
            this.ctlDecryptFieldMNU.Click += new System.EventHandler(this.ctlDecryptFieldMNU_Click);
            // 
            // ctlDecryptColumnMNU
            // 
            this.ctlDecryptColumnMNU.Name = "ctlDecryptColumnMNU";
            this.ctlDecryptColumnMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlDecryptColumnMNU.Text = "Current &Column";
            this.ctlDecryptColumnMNU.Click += new System.EventHandler(this.ctlDecryptColumnMNU_Click);
            // 
            // ctlDecryptRowMNU
            // 
            this.ctlDecryptRowMNU.Name = "ctlDecryptRowMNU";
            this.ctlDecryptRowMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlDecryptRowMNU.Text = "Current &Row";
            this.ctlDecryptRowMNU.Click += new System.EventHandler(this.ctlDecryptRowMNU_Click);
            // 
            // ctlDecryptTableMNU
            // 
            this.ctlDecryptTableMNU.Name = "ctlDecryptTableMNU";
            this.ctlDecryptTableMNU.Size = new System.Drawing.Size(160, 22);
            this.ctlDecryptTableMNU.Text = "Current &Table";
            this.ctlDecryptTableMNU.Click += new System.EventHandler(this.ctlDecryptTableMNU_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlHelpAboutMNU});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // ctlHelpAboutMNU
            // 
            this.ctlHelpAboutMNU.Name = "ctlHelpAboutMNU";
            this.ctlHelpAboutMNU.Size = new System.Drawing.Size(114, 22);
            this.ctlHelpAboutMNU.Text = "&About";
            this.ctlHelpAboutMNU.Click += new System.EventHandler(this.ctlHelpAboutMNU_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(191, 6);
            // 
            // ctlFilePrintDgvControlMNU
            // 
            this.ctlFilePrintDgvControlMNU.Name = "ctlFilePrintDgvControlMNU";
            this.ctlFilePrintDgvControlMNU.Size = new System.Drawing.Size(212, 22);
            this.ctlFilePrintDgvControlMNU.Text = "Print DataGridView Control";
            this.ctlFilePrintDgvControlMNU.Click += new System.EventHandler(this.ctlFilePrintDgvControlMNU_Click);
            // 
            // ctlPrintHowMNU
            // 
            this.ctlPrintHowMNU.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctlPrintHowEverythingMNU,
            this.ctlPrintHowSelectedColumnMNU});
            this.ctlPrintHowMNU.Name = "ctlPrintHowMNU";
            this.ctlPrintHowMNU.Size = new System.Drawing.Size(194, 22);
            this.ctlPrintHowMNU.Text = "Print How";
            // 
            // ctlPrintHowEverythingMNU
            // 
            this.ctlPrintHowEverythingMNU.Checked = true;
            this.ctlPrintHowEverythingMNU.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ctlPrintHowEverythingMNU.Name = "ctlPrintHowEverythingMNU";
            this.ctlPrintHowEverythingMNU.Size = new System.Drawing.Size(169, 22);
            this.ctlPrintHowEverythingMNU.Text = "Everything";
            this.ctlPrintHowEverythingMNU.Click += new System.EventHandler(this.ctlPrintHowEverythingMNU_Click);
            // 
            // ctlPrintHowSelectedColumnMNU
            // 
            this.ctlPrintHowSelectedColumnMNU.Name = "ctlPrintHowSelectedColumnMNU";
            this.ctlPrintHowSelectedColumnMNU.Size = new System.Drawing.Size(169, 22);
            this.ctlPrintHowSelectedColumnMNU.Text = "Selected Columns";
            this.ctlPrintHowSelectedColumnMNU.Click += new System.EventHandler(this.ctlPrintHowSelectedColumnMNU_Click);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 443);
            this.Controls.Add(this.ctlTableDGV);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Shown += new System.EventHandler(this.OnFormShown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnFormClosing);
            this.Load += new System.EventHandler(this.OnFormLoad);
            ((System.ComponentModel.ISupportInitialize)(this.ctlTableDGV)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ctlTableDGV;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ctlFile_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFileNewMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFileOpenMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFileSaveMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFileSaveAsMNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ctlFileExitMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlRecord_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlRecordAddMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlRecordDeleteMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlRecordUpdateMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlCrypto_MNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFieldEncryptMNU;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ctlHelpAboutMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFieldDecryptMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlCryptoPasswordMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlEncryptFieldMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlEncryptColumnMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlEncryptRowMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlEncryptTableMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlDecryptFieldMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlDecryptColumnMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlDecryptRowMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlDecryptTableMNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem ctlFilePrintMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFilePrintPreviewMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlFilePrintScreenshotMNU;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ctlFilePrintDgvControlMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlPrintHowMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlPrintHowEverythingMNU;
        private System.Windows.Forms.ToolStripMenuItem ctlPrintHowSelectedColumnMNU;
    }
}

