using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;

//****************************************************************
// C# version, inspired by VB-based CodeProject article
// ".NET cryptography library for files and strings" By HanreG. 
// See http://www.codeproject.com/dotnet/CryptoLib.asp for details
//****************************************************************

/*************************************************************************************
    DISCLAIMER
    I undertook this project to help a friend and, in the process, also learn a  
    few things about Visual Studio 2005, C#, XML, DataGridView, cryptography, etc. 
    Caveat Emptor: Nothing has been properly or adequately tested. 
    More important, there is a good chance, you or someone else can do this better.
    So if you do use this code and cannot decrypt something, there is little I or anyone 
    can do to help you. On the bright side, though, since you have the source code, 
    you can make it more bullet-proof to suit your needs.
 *************************************************************************************/

namespace VVX
{
    class CryptoLib
    {
        //originally named EncryptStringToBase64String(...)
        public string EncryptString(string value , string password)
        {
		    return this.EncryptString(value, password, null);
	    }

        //originally named EncryptStringToBase64String(...)
        public string EncryptString(string value, string password, SymmetricAlgorithm provider)
        {
		    Byte[] passwordBytes;
		    Byte[] key;
		    MemoryStream memoryStream;
		    CryptoStream cryptoStream;
		    string header;
            string output;

		    if (value == null || value == "")
            {
			    throw new ArgumentNullException("value", "'value' should not be Nothing (null in C#) or String.Empty.");
            }
		
            if (password == null || password == "")
            {
                throw new ArgumentNullException("password", "'password' should not be Nothing (null in C#) or String.Empty.");
            }

		    if (provider == null)
                provider = new RijndaelManaged();

            int nSize = provider.LegalKeySizes[0].MaxSize;
            nSize = nSize / 8;
            //nSize = nSize - 1;
            //key = new byte[provider.LegalKeySizes[0].MaxSize \ 8 - 1];
            key = new byte[nSize];

            provider.BlockSize = provider.LegalBlockSizes[0].MaxSize;

            passwordBytes = this.HashStringToByteArray(password);

		    Array.Copy(passwordBytes, key, key.Length);

		    provider.Key = key;
            provider.GenerateIV();

            header = this.HashStringToBase64String(Convert.ToBase64String(passwordBytes)
                                                 + Convert.ToBase64String(provider.IV)).PadRight(127)
                                                 + Convert.ToBase64String(provider.IV).PadRight(127);

            Type t = provider.GetType();
            if (t == typeof(DESCryptoServiceProvider))
			    header += "01";
            else if (t == typeof(RC2CryptoServiceProvider))
			    header += "02";
            else if (t == typeof(TripleDESCryptoServiceProvider))
			    header += "03";
            else if (t == typeof(RijndaelManaged))
			    header += "04";

            memoryStream = new MemoryStream();
            memoryStream.SetLength(0);

            cryptoStream = new CryptoStream(memoryStream, provider.CreateEncryptor(), CryptoStreamMode.Write);

		    cryptoStream.Write(Encoding.ASCII.GetBytes(value), 0, Encoding.ASCII.GetBytes(value).Length);
		    cryptoStream.FlushFinalBlock();

		    output = header + Convert.ToBase64String(memoryStream.ToArray());

		    memoryStream.Close();
		    cryptoStream.Clear();
            provider.Clear();

            Debug.WriteLine(output);

            return output;
        }

	    public Byte[] HashStringToByteArray(string value) 
        {
		    return this.HashStringToByteArray(value, null);
	    }

        public Byte[] HashStringToByteArray(string value, HashAlgorithm provider)
        {
		    if (value == null || value == "")
            {
			    throw new ArgumentNullException("value", "'value' should not be Nothing (null in C#) or String.Empty.");
		    }

		    Byte[] bytes;

		    if (provider == null)
                provider = new SHA512Managed();

		    bytes = ASCIIEncoding.ASCII.GetBytes(value);
		    bytes = provider.ComputeHash(bytes);
		    provider.Clear();

            return bytes;
        }

	    public string HashStringToBase64String(string value )
        {
		    return this.HashStringToBase64String(value, null);
	    }

	    public string HashStringToBase64String(string value, HashAlgorithm provider)
        {
		    if (value == null || value == "")
            {
			    throw new ArgumentNullException("value", "'value' should not be Nothing (null in C#) or String.Empty.");
		    }

		    Byte[] bytes;

		    if (provider==null)
                provider = new SHA512Managed();
		    bytes = ASCIIEncoding.ASCII.GetBytes(value);
		    bytes = provider.ComputeHash(bytes);
		    provider.Clear();

            return Convert.ToBase64String(bytes);
	    }

        //originally named DecryptStringFromBase64String(...)
        public string DecryptString(string value, string password)
        {
		    SymmetricAlgorithm provider;
		    Byte[] passwordBytes;
		    Byte[] key;
		    MemoryStream memoryStream;
		    CryptoStream cryptoStream;
            string output;

            if (value==null || value == "")
            {
			    throw new ArgumentNullException("value", "'value' should not be Nothing (null in C#) or String.Empty.");
		    }

		    if (password == null || password == "")
            {
			    throw new ArgumentNullException("password", "'password' should not be Nothing (null in C#) or String.Empty.");
		    }

		    switch(value.Substring (254, 2))
            {
			    case "01":
				    provider = new DESCryptoServiceProvider();
                    break;
			    case "02":
				    provider = new RC2CryptoServiceProvider();
                    break;
                case "03":
				    provider = new TripleDESCryptoServiceProvider();
                    break;
                default:
                case "04":
				    provider = new RijndaelManaged();
                    break;
            }

		    key = new byte[provider.LegalKeySizes[0].MaxSize / 8];

	        provider.BlockSize = provider.LegalBlockSizes[0].MaxSize;

	        passwordBytes = this.HashStringToByteArray(password);

	        Array.Copy(passwordBytes, key, key.Length);

	        provider.Key = key;
	        provider.IV = Convert.FromBase64String(value.Substring(127, 127).Trim());

       		if (value.Substring(0, 127).Trim() != this.HashStringToBase64String(Convert.ToBase64String(passwordBytes) + Convert.ToBase64String(provider.IV)))
            {
			    //'If the password is incorrect, do some clean up before throwing an exception.
			    provider.Clear();
                throw new ArgumentException("The password specified is invalid.");
		    }

		    memoryStream = new MemoryStream();
		    memoryStream.SetLength(0);

    		cryptoStream = new CryptoStream(memoryStream, provider.CreateDecryptor()
                                                , CryptoStreamMode.Write);

       		cryptoStream.Write(Convert.FromBase64String(value.Substring(256)), 0
                             , Convert.FromBase64String(value.Substring(256)).Length);
		    cryptoStream.FlushFinalBlock();

		    output = ASCIIEncoding.ASCII.GetString(memoryStream.ToArray());

		    memoryStream.Close();
		    cryptoStream.Clear();
		    provider.Clear();

            return output;
        }
    }
}
