using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;

using VVX;

namespace XmlStoreClient
{
    /// <summary>
    /// A simple form with a DataGridView and a few menu commands for viewing/editing
    /// a VVX.XmlStore XML file. It also allows you to encrypt/decrypt a single cell,
    /// or an entire column, or an entire row, or the entire table based on a password
    /// WARNING: IT DOES NOT SAVE THE PASSWORD used for encryption. So if you forget
    /// the password, potentially the information in the XmlStore is LOST FOREVER!
    /// 
    /// Part 2: Support for printing the contents of the DataGridView 
    /// (i.e, the XmlStore data displayed in it).
    /// </summary>
    public partial class Form_Main : Form
    {
        private string msAppName = "XmlStoreClient Part2: ";

        private VVX.XmlStore mXmlStore;
        private string msXmlStoreFile = "";

        private bool mbSetRowHeaderLabel = !false;   
        private bool mbTableModified = false;
        private bool mbTableSaved = true;

        private string msCryptoPassword = "";

        public Form_Main()
        {
            InitializeComponent();
            this.DoPopupMenus_Build();
            this.DoUpdateCaption();
        }

        #region Form Event Handlers/helpers

        private void OnFormLoad(object sender, EventArgs e)
        {
            this.DoGridCustomization(this.ctlTableDGV);
        }

        private void OnFormShown(object sender, EventArgs e)
        {
            VVX.About.Show();       //OK to comment out

            //let user open an XmlStore file
            if (!this.DoFileOpen())
                this.DoFileClose(true);

        }
        
        #endregion //Form Event Handlers/helpers

        #region Main DataGridView helpers
        /// <summary>
        /// Normally invoked once at startup
        /// </summary>
        /// <param name="dgv">The DataGridView to be customized</param>
        private void DoGridCustomization(DataGridView dgv)
        {
            //--- configure the GRID
            dgv.Name = "Table";
            //dgv.Location = new Point(8, 8);
            //dgv.Size = new Size(500, 250);
            dgv.Dock = DockStyle.Fill;

            //--- if you don't want an empty "new row" to be displayed at the bottom
            //    set AllowUserToAddRows = false;
            dgv.AllowUserToAddRows = false;

            //--- to speed up the "painting" of the grid
            //    set AutoSizeColumnsMode and AutoSizeRowsMode to "None." 
            //    Ref:http://www.developerdotstar.com/community/node/706
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            //dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;

            //--- configure the ROW and COLUMN HEADERS
            dgv.RowHeadersVisible = true;
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            //dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //dgv.ColumnHeadersDefaultCellStyle.Font = new Font(dgv.Font, FontStyle.Bold);
            //--- to speed up the "painting" of the grid
            //    Ref:http://www.developerdotstar.com/community/node/706
            //    set EnableVisualStyles=false
            //dgv.EnableHeadersVisualStyles= false;
            //dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;

            //--- to speed up the "painting" of the grid
            //    set CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
            //    Ref:https://connect.microsoft.com/VisualStudio/feedback/ViewFeedback.aspx?FeedbackID=117093
            //    and http://blogs.msdn.com/jfoscoding/archive/2005/11/16/493727.aspx
            //    and http://www.windowsforms.net/Default.aspx?tabindex=4&tabid=49#Data%20Access

            //--- configure CELLS
            //dgv.GridColor = Color.Black;
            //dgv.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            //dgv.CellBorderStyle = DataGridViewCellBorderStyle.None;

            //--- configure other things

            //--- Add default Excel-like column headers
            dgv.Columns.Clear();
            int start = (int)'A';
            for (int i = 0; i < 26; i++)
            {
                string colName = ((char)(i + start)).ToString();
                int index = dgv.Columns.Add(colName, colName);
                dgv.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
                dgv.Columns[i].Width = 75;
            }

            //--- Add add empty rows
            //this.mbSetRowHeaderLabel = false;  //Used by OnRowsAdded(...)
            dgv.RowHeadersWidth = 49;
            for (int i = 0; i < 50; i++)
            {
                dgv.Rows.Add(); //generates an event --> OnRowsAdded(...)
            }

            //--- specify how the user SELECTs one or more cells
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.CellSelect;
            //dgv.SelectionMode = DataGridViewSelectionMode.ColumnHeaderSelect;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullColumnSelect;
            //dgv.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
            //dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            //--- define an event handler that allows you to format each cell
            dgv.CellFormatting += 
                new DataGridViewCellFormattingEventHandler(OnCellFormatting);
        }

        /// <summary>
        /// Invoked after an XmlStore file is opened by user to display its contents
        /// in a DataGridView
        /// </summary>
        /// <param name="dgv">DataGridView instance in which to display the data</param>
        private void DoGridPopulate(DataGridView dgv)
        {
            int numRecordsInXml = 0;
            try
            {
                if (this.msXmlStoreFile.Length > 0)
                {
                    this.mXmlStore = new XmlStore(this.msXmlStoreFile);

                    numRecordsInXml = this.mXmlStore.DoLoadRecords();

                    if (numRecordsInXml > 0)
                    {
                        dgv.Columns.Clear();
                        dgv.ColumnCount = this.mXmlStore.Fields.Length;
                        bool bHasID = false;
                        int n = 0;
                        for (n = 0; n < dgv.ColumnCount; n++)
                        {
                            dgv.Columns[n].Name = this.mXmlStore.Fields[n].title;
                            if (bHasID == false)
                                bHasID = (dgv.Columns[n].Name.ToUpper() == this.mXmlStore.NameOfFieldWithUniqueID);
                        }
                        if (!bHasID)
                        {
                            dgv.ColumnCount++;
                            dgv.Columns[n].Name = this.mXmlStore.NameOfFieldWithUniqueID;
                        }

                        for (int i = 0; i < numRecordsInXml; i++)
                        {
                            string[] rowCells = this.mXmlStore.DoGetRecord(i);
                            dgv.Rows.Add(rowCells);
                        }
                    
                        if (this.mXmlStore.IsReadOnly)
                        {
                            MsgBox.Warning("The XmlStore file is 'ReadOnly'. You will not be able to save any changes");
                        }
                    }
                }
                else
                {
                    VVX.MsgBox.Error("Need file name to open");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
        }
        #endregion //Main DataGridView helpers
        
        #region Event Handler Helpers
        //************************************************************
        /// <summary>
        /// Refreshes the window's Caption/Title bar
        /// </summary>
        private void DoUpdateCaption()
        {
            this.Text = this.msAppName;

            if (this.msXmlStoreFile.Length == 0)
            {
                this.Text += "<no source file>";
                this.ctlFileNewMNU.Enabled = false;
            }
            else
            {
                FileInfo fi = new FileInfo(this.msXmlStoreFile);
                this.Text += @"...\" + fi.Name;

                if (this.mbTableModified)
                {
                    //indicate that changes not yet in this.mXmlStore (i.e., in memory)
                    this.Text += " *";  
                }

                if (this.mXmlStore.IsReadOnly)
                {
                    //indicate that changes cannot be saved to this file
                    this.Text += " [READ ONLY]";
                }
                
                if (!this.mbTableSaved)
                {
                    //indicate that changes not yet in the XmlStore file
                    this.Text += " [Changes NOT Saved]";
                }


                this.ctlFileNewMNU.Enabled = true;

            }
        }

        private bool DoFileNew()
        {
            //this.mbTableModified = false;
            //this.mbTableSaved = true;
            //this.DoUpdateCaption();
            VVX.MsgBox.Info("Sorry! Not yet implemented");
            return false;
        }

        /// <summary>
        /// Processes the File Open request
        /// </summary>
        /// <returns>true if successful</returns>
        private bool DoFileOpen()
        {
            bool bRet = false;
            this.DoPreClose();
            this.msXmlStoreFile = VVX.FileDialog.GetFilenameToOpen(VVX.FileDialog.FileType.XML);
            if (this.msXmlStoreFile.Length > 0)
            {
                this.mbTableModified = false;
                this.mbTableSaved = true;
                this.DoGridPopulate(this.ctlTableDGV);
                bRet = true;
            }

            this.DoUpdateCaption();

            return bRet;
        }

        /// <summary>
        /// Performs needed "pre-save" tasks, such as ending the edit mode, updating the record,
        /// in the XmlStore's XmlDocument, etc. 
        /// </summary>
        private void DoPreSaveTasks()
        {
            if (this.ctlTableDGV.IsCurrentCellInEditMode)
            {
                this.ctlTableDGV.EndEdit();
                this.DoRecordUpdate();
            }
            else
            {
                if (this.mbTableModified)
                {
                    this.DoRecordUpdate();
                }
            }
        }

        /// <summary>
        /// Processes the File Save As request
        /// </summary>
        private void DoFileSaveAs(bool bPromptForFilename)
        {
            this.DoPreSaveTasks();
            string sFile = this.msXmlStoreFile;  //.Replace(".xml", ".out.xml");
            if(bPromptForFilename || sFile.Length == 0)
                sFile = VVX.FileDialog.GetFilenameToSave(VVX.FileDialog.FileType.XML, sFile);
            bool bRemoveIdColIfAdded = true;
            int count = this.mXmlStore.DoSaveRecords(sFile, bRemoveIdColIfAdded);
            if (count > 0)
            {
                this.mbTableModified = false;
                this.mbTableSaved = true;
                this.DoUpdateCaption();
            }
        }

        /// <summary>
        /// Performs Pre-close tasks, giving the user a chance to save changes
        /// </summary>
        private void DoPreClose()
        {
            if (this.mbTableModified || !this.mbTableSaved)
            {
                if (MsgBox.Confirm("Save changes?"))
                    this.DoFileSaveAs(false);
            }
        }

        /// <summary>
        /// Gives user a chance to save and changes and confirm Exit request.
        /// </summary>
        /// <param name="bSkipConfirm"></param>
        private void DoFileClose(bool bSkipConfirm)
        {
            this.DoPreClose();
            if (bSkipConfirm || MsgBox.Confirm("OK to exit?"))
                this.Close();
        }

        /// <summary>
        /// Inserts an empty row at the bottom of the grid and then sets the focus 
        /// in the first cell of that row.
        /// </summary>
        private void DoRecordAdd()
        {
            if (this.mXmlStore != null)
            {
                this.ctlTableDGV.EndEdit();
                string[] rowCells = this.mXmlStore.DoGetRecordNew();
                int nRet = this.ctlTableDGV.Rows.Add(rowCells);
                Debug.WriteLine("nRet=" + nRet.ToString());
                this.ctlTableDGV.CurrentCell = this.ctlTableDGV[0, nRet];
            }
        }

        private bool DoRecordDelete()
        {
            VVX.MsgBox.Info("Sorry! Not yet implemented");
            return false;
        }

        /// <summary>
        /// Processes request to post changes from the DataGridView to the XmlDataStore.
        /// Until this is called, changes will not be sent to the XmlStore.
        /// WARNING: This only updates the "current row".
        /// </summary>
        /// <returns></returns>
        private bool DoRecordUpdate()
        {
            bool bRet = false;
            if (this.mXmlStore != null)
            {
                this.ctlTableDGV.EndEdit();
                DataGridViewCellCollection dgvCells = this.ctlTableDGV.CurrentRow.Cells;
                int nRow = this.ctlTableDGV.CurrentRow.Cells[0].RowIndex;
                string[] rowCells = new string[dgvCells.Count];
                for (int n = 0; n < dgvCells.Count; n++)
                {
                    rowCells[n] = dgvCells[n].Value.ToString();
                }
                this.mXmlStore.DoSetRecord(nRow, rowCells);
                bRet = true;

                this.mbTableModified = false;
                this.DoUpdateCaption();
            }
            return bRet;
        }

        private bool DoRecordUpdate(int nRow)
        {
            bool bRet = false;
            if (this.mXmlStore != null)
            {
                this.ctlTableDGV.EndEdit();
                int cols = this.ctlTableDGV.ColumnCount;
                string[] rowCells = new string[cols];
                for (int n = 0; n < cols; n++)
                {
                    rowCells[n] = this.ctlTableDGV[n, nRow].Value.ToString();
                }
                this.mXmlStore.DoSetRecord(nRow, rowCells);
                bRet = true;

                this.mbTableModified = false;
                this.DoUpdateCaption();
            }
            return bRet;
        }

        private void OnRowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            int nRow = 1 + e.RowIndex;
            if (this.mbSetRowHeaderLabel)
                this.ctlTableDGV.Rows[e.RowIndex].HeaderCell.Value = nRow.ToString();
        }

        private void OnCellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //--- make the ID column (a) readonly, with a different color, and a specific width
            //    BUT DO IT ONLY ONCE
            DataGridViewColumn dgvColumn = this.ctlTableDGV.Columns[e.ColumnIndex];
            if (this.mXmlStore != null 
             && dgvColumn.Name == this.mXmlStore.NameOfFieldWithUniqueID)
            {
                //if (dgvColumn.ReadOnly == false)
                {
                    dgvColumn.ReadOnly = true;
                    dgvColumn.DefaultCellStyle.BackColor = Color.BlanchedAlmond;
                    //dgvColumn.DefaultCellStyle.ForeColor = Color.BlanchedAlmond;
                    dgvColumn.Resizable = DataGridViewTriState.False;
                    dgvColumn.MinimumWidth = 2;
                    dgvColumn.Width = 2;
                }
            }

#if false
            //if Column type is Date, display it as appropriate
            // HERE FOR ILLUSTRATION ONLY
            if (this.ctlTableDGV.Columns[e.ColumnIndex].Name == "Release Date")
            {
                if (e != null)
                {
                    if (e.Value != null)
                    {
                        try
                        {
                            e.Value = DateTime.Parse(e.Value.ToString())
                                .ToLongDateString();
                            e.FormattingApplied = true;
                        }
                        catch (FormatException)
                        {
                            Debug.WriteLine("{0} is not a valid date.", e.Value.ToString());
                        }
                    }
                }
            }
#endif
        }

        #region Encryption Helpers
        private bool DoFieldPasswordEdit()
        {
            Form_Password dlg = new Form_Password();

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                this.msCryptoPassword = dlg.Password;
            }

            return (this.msCryptoPassword.Length > 0);
        }

        private string DoStringEncrypt(string sValue)
        {
            string sRet = "";
            VVX.CryptoLib crypto = new CryptoLib();

            try
            {
                string sMsg = "";
                bool bOk = true;

                if (this.msCryptoPassword.Length == 0)
                    bOk = this.DoFieldPasswordEdit();

                if (bOk)
                {
                    if (this.msCryptoPassword.Length > 0)
                    {
                        string sPassword = this.msCryptoPassword;
                        string sEncrypted = crypto.EncryptString(sValue, sPassword);
                        sRet = sEncrypted;
#if false
                    string sDecrypted = crypto.DecryptString(sEncrypted, sPassword);
                    if (sValue == sDecrypted)
                        sMsg = "SUCCESS";
                    else
                        sMsg = "FAILURE";
#endif
                    }
                    else
                    {
                        sMsg = "Cannot encrypt without a password";
                    }
                }
                else
                {
                    sMsg = "Request cancelled";
                }
                if (sMsg.Length > 0)
                    VVX.MsgBox.Info(sMsg);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            finally
            {
                crypto = null;
            }

            return sRet;
        }

        private string DoStringDecrypt(string sValue)
        {
            string sRet = "";
            VVX.CryptoLib crypto = new CryptoLib();

            try
            {
                string sMsg = "";
                bool bOk = true;

                if (this.msCryptoPassword.Length == 0)
                    bOk = this.DoFieldPasswordEdit();

                if (bOk)
                {
                    if (this.msCryptoPassword.Length > 0)
                    {
                        string sPassword = this.msCryptoPassword;
                        string sDecrypted = crypto.DecryptString(sValue, sPassword);
                        sRet = sDecrypted;
#if false
                    string sEncrypted = crypto.EncryptString(sDecrypted, sPassword);
                    if (sValue == sDecrypted)
                        sMsg = "SUCCESS";
                    else
                        sMsg = "FAILURE";
#endif
                    }
                    else
                    {
                        sMsg = "Cannot decrypt without a password";
                    }
                }
                else
                {
                    sMsg = "Request cancelled";
                }
                if (sMsg.Length > 0)
                    VVX.MsgBox.Info(sMsg);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            finally
            {
                crypto = null;
            }

            return sRet;
        }

        private int DoEncryptRange(int colFr, int colTo, int rowFr, int rowTo)
        {
            int count = 0;
            for (int row = rowFr; row <= rowTo; row++)
            {
                for (int col = colFr; col <= colTo; col++)
                {
                    if (col != this.mXmlStore.ColumnUID)
                    {
                        string sValue = this.ctlTableDGV[col, row].Value.ToString();
                        string sEncrypted = this.DoStringEncrypt(sValue);
                        if (sEncrypted.Length > 0)
                        {
                            this.ctlTableDGV[col, row].Value = sEncrypted;
                            this.mbTableModified = true;
                            this.mbTableSaved = false;
                            count++;
                        }
                        else
                        {
                            if(this.msCryptoPassword == "")
                                return count;
                        }
                    }
                }
                this.DoRecordUpdate(row);
            }

            this.DoUpdateCaption();
            return count;
        }

        private int DoDecryptRange(int colFr, int colTo, int rowFr, int rowTo)
        {
            int count = 0;
            for (int row = rowFr; row <= rowTo; row++)
            {
                for (int col = colFr; col <= colTo; col++)
                {
                    if (col != this.mXmlStore.ColumnUID)
                    {
                        string sValue = this.ctlTableDGV[col, row].Value.ToString();
                        string sDecrypted = this.DoStringDecrypt(sValue);
                        if (sDecrypted.Length > 0)
                        {
                            this.ctlTableDGV[col, row].Value = sDecrypted;
                            this.mbTableModified = true;
                            this.mbTableSaved = false;
                            count++;
                        }
                        else
                        {
                            if (this.msCryptoPassword == "")
                                return count;
                        }
                    }
                }
                this.DoRecordUpdate(row);
            }

            this.DoUpdateCaption();
            return count;
        }

        #endregion //Encryption Helpers

        //************************************************************
        #endregion //Event Handler Helpers

        #region Event Handlers
        //************************************************************
        #region FORM Event Handlers
        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            this.DoPreClose();
        }
        #endregion //FORM Event Handlers
        
        #region FILE menu Event Handlers
        private void ctlFileNewMNU_Click(object sender, EventArgs e)
        {
            this.DoFileNew();
        }

        private void ctlFileOpenMNU_Click(object sender, EventArgs e)
        {
            this.DoFileOpen();
        }

        private void ctlFileSaveMNU_Click(object sender, EventArgs e)
        {
            this.DoFileSaveAs(false);
        }

        private void ctlFileSaveAsMNU_Click(object sender, EventArgs e)
        {
            this.DoFileSaveAs(true);
        }

        private void ctlFileExitMNU_Click(object sender, EventArgs e)
        {
            bool bSkipConfirm = false;
            DoFileClose(bSkipConfirm);
        }

        private void ctlFilePrintScreenshotMNU_Click(object sender, EventArgs e)
        {
            VVX.Print printForm = new Print();

            printForm.DoPrintControl(this, true, true, true, true);
        }

        private void ctlFilePrintDgvControlMNU_Click(object sender, EventArgs e)
        {
            VVX.Print printControl = new Print();

            printControl.DoPrintControl(this.ctlTableDGV, true, true, true, true);
        }

        #endregion //FILE menu Event Handlers

        #region RECORD menu Event Handlers
        private void ctlRecordAddMNU_Click(object sender, EventArgs e)
        {
            this.DoRecordAdd();
        }

        private void ctlRecordDeleteMNU_Click(object sender, EventArgs e)
        {
            this.DoRecordDelete();
        }

        private void ctlRecordUpdateMNU_Click(object sender, EventArgs e)
        {
            this.DoRecordUpdate();
        }

        #endregion //RECORD menu Event Handlers

        #region HELP menu Event Handlers
        private void ctlHelpAboutMNU_Click(object sender, EventArgs e)
        {
            About.Show();
        }
        #endregion //HELP menu Event Handlers

        #region DataGridView Event Handlers
        private void OnCellChanged(object sender, EventArgs e)
        {
            //if(this.ctlTableDGV.IsCurrentRowDirty)
        }

        private void OnEditModeChanged(object sender, EventArgs e)
        {
        }

        private void OnCellEditBegin(object sender, DataGridViewCellCancelEventArgs e)
        {
            this.mbTableModified = true;
            this.mbTableSaved = false;
            this.DoUpdateCaption();
        }

        private void OnCellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }
        #endregion //DataGridView Event Handlers

        #region Encryption menu Event Handlers
        private void ctlFieldPasswordMNU_Click(object sender, EventArgs e)
        {
            DoFieldPasswordEdit();
        }

        private void ctlEncryptFieldMNU_Click(object sender, EventArgs e)
        {
            //current cell only
            int colFr = this.ctlTableDGV.CurrentCell.ColumnIndex;
            int colTo = colFr;
            int rowFr = this.ctlTableDGV.CurrentCell.RowIndex;
            int rowTo = rowFr;
            this.DoEncryptRange(colFr, colTo, rowFr, rowTo);
        }

        private void ctlEncryptColumnMNU_Click(object sender, EventArgs e)
        {
            // all rows in current column
            int colFr = this.ctlTableDGV.CurrentCell.ColumnIndex;
            int colTo = colFr;
            int rowFr = 0;
            int rowTo = this.ctlTableDGV.Rows.Count-1;
            this.DoEncryptRange(colFr, colTo, rowFr, rowTo);
        }

        private void ctlEncryptRowMNU_Click(object sender, EventArgs e)
        {
            // all columns in current row
            int colFr = 0;
            int colTo = this.ctlTableDGV.ColumnCount-1;
            int rowFr = this.ctlTableDGV.CurrentCell.RowIndex;
            int rowTo = rowFr;
            this.DoEncryptRange(colFr, colTo, rowFr, rowTo);
        }

        private void ctlEncryptTableMNU_Click(object sender, EventArgs e)
        {
            // all columns in all rows
            int colFr = 0;
            int colTo = this.ctlTableDGV.ColumnCount-1;
            int rowFr = 0;
            int rowTo = this.ctlTableDGV.Rows.Count-1;
            this.DoEncryptRange(colFr, colTo, rowFr, rowTo);
        }

        private void ctlDecryptFieldMNU_Click(object sender, EventArgs e)
        {
            //current cell only
            int colFr = this.ctlTableDGV.CurrentCell.ColumnIndex;
            int colTo = colFr;
            int rowFr = this.ctlTableDGV.CurrentCell.RowIndex;
            int rowTo = rowFr;
            this.DoDecryptRange(colFr, colTo, rowFr, rowTo);

        }

        private void ctlDecryptColumnMNU_Click(object sender, EventArgs e)
        {
            // all rows in current column
            int colFr = this.ctlTableDGV.CurrentCell.ColumnIndex;
            int colTo = colFr;
            int rowFr = 0;
            int rowTo = this.ctlTableDGV.Rows.Count-1;
            this.DoDecryptRange(colFr, colTo, rowFr, rowTo);

        }

        private void ctlDecryptRowMNU_Click(object sender, EventArgs e)
        {
            // all columns in current row
            int colFr = 0;
            int colTo = this.ctlTableDGV.ColumnCount-1;
            int rowFr = this.ctlTableDGV.CurrentCell.RowIndex;
            int rowTo = rowFr;
            this.DoDecryptRange(colFr, colTo, rowFr, rowTo);
        }

        private void ctlDecryptTableMNU_Click(object sender, EventArgs e)
        {
            // all columns in all rows
            int colFr = 0;
            int colTo = this.ctlTableDGV.ColumnCount-1;
            int rowFr = 0;
            int rowTo = this.ctlTableDGV.Rows.Count-1;
            this.DoDecryptRange(colFr, colTo, rowFr, rowTo);
        }
        #endregion //Encryption menu Event Handlers

        #region Popup Menus

        #region Popup Menus Builder

        private void DoPopupMenus_Build()
        {
            this.DoPopupCellMenu_Init();
            this.DoPopupColumnMenu_Init();
            this.DoPopupRowMenu_Init();
            this.DoPopupTableMenu_Init();
        }

        private ContextMenuStrip ctlPopupCell_MNU = new ContextMenuStrip();
        private ToolStripMenuItem ctlPopupCellEncryptMNU = new ToolStripMenuItem();
        private ToolStripMenuItem ctlPopupCellDecryptMNU = new ToolStripMenuItem();
        private void DoPopupCellMenu_Init()
        {
            // --- Encrypt menu
            ctlPopupCellEncryptMNU.Name = "ctlPopupCellEncryptMNU";
            ctlPopupCellEncryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupCellEncryptMNU.Text = "Encrypt Cell";
            ctlPopupCellEncryptMNU.Click += new System.EventHandler(ctlEncryptFieldMNU_Click);
            // --- Decrypt menu
            ctlPopupCellDecryptMNU.Name = "ctlPopupCellDecryptMNU";
            ctlPopupCellDecryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupCellDecryptMNU.Text = "Decrypt Cell";
            ctlPopupCellDecryptMNU.Click += new System.EventHandler(ctlDecryptFieldMNU_Click);
            // --- now build the popup menu
            ToolStripItem[] mnuOptions = new ToolStripItem[2] 
                                        {   ctlPopupCellEncryptMNU
                                          , ctlPopupCellDecryptMNU 
                                        };
            ctlPopupCell_MNU.Items.AddRange(mnuOptions);
            ctlPopupCell_MNU.Name = "ctlPopupCell_MNU";
            ctlPopupCell_MNU.Size = new System.Drawing.Size(123, 48);
        }

        private ContextMenuStrip ctlPopupColumn_MNU = new ContextMenuStrip();
        private ToolStripMenuItem ctlPopupColumnEncryptMNU = new ToolStripMenuItem();
        private ToolStripMenuItem ctlPopupColumnDecryptMNU = new ToolStripMenuItem();
        private void DoPopupColumnMenu_Init()
        {
            // --- Encrypt menu
            ctlPopupColumnEncryptMNU.Name = "ctlPopupColumnEncryptMNU";
            ctlPopupColumnEncryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupColumnEncryptMNU.Text = "Encrypt Column";
            ctlPopupColumnEncryptMNU.Click += new System.EventHandler(ctlEncryptColumnMNU_Click);
            // --- Decrypt menu
            ctlPopupColumnDecryptMNU.Name = "ctlPopupColumnDecryptMNU";
            ctlPopupColumnDecryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupColumnDecryptMNU.Text = "Decrypt Column";
            ctlPopupColumnDecryptMNU.Click += new System.EventHandler(ctlDecryptColumnMNU_Click);
            // --- now build the popup menu
            ToolStripItem[] mnuOptions = new ToolStripItem[2] 
                                        {   ctlPopupColumnEncryptMNU
                                          , ctlPopupColumnDecryptMNU 
                                        };
            ctlPopupColumn_MNU.Items.AddRange(mnuOptions);
            ctlPopupColumn_MNU.Name = "ctlPopupColumn_MNU";
            ctlPopupColumn_MNU.Size = new System.Drawing.Size(123, 48);
        }

        private ContextMenuStrip ctlPopupRow_MNU = new ContextMenuStrip();
        private ToolStripMenuItem ctlPopupRowEncryptMNU = new ToolStripMenuItem();
        private ToolStripMenuItem ctlPopupRowDecryptMNU = new ToolStripMenuItem();
        private void DoPopupRowMenu_Init()
        {
            // --- Encrypt menu
            ctlPopupRowEncryptMNU.Name = "ctlPopupRowEncryptMNU";
            ctlPopupRowEncryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupRowEncryptMNU.Text = "Encrypt Row";
            ctlPopupRowEncryptMNU.Click += new System.EventHandler(ctlEncryptRowMNU_Click);
            // --- Decrypt menu
            ctlPopupRowDecryptMNU.Name = "ctlPopupRowDecryptMNU";
            ctlPopupRowDecryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupRowDecryptMNU.Text = "Decrypt Row";
            ctlPopupRowDecryptMNU.Click += new System.EventHandler(ctlDecryptRowMNU_Click);
            // --- now build the popup menu
            ToolStripItem[] mnuOptions = new ToolStripItem[2] 
                                        {   ctlPopupRowEncryptMNU
                                          , ctlPopupRowDecryptMNU 
                                        };
            ctlPopupRow_MNU.Items.AddRange(mnuOptions);
            ctlPopupRow_MNU.Name = "ctlPopupRow_MNU";
            ctlPopupRow_MNU.Size = new System.Drawing.Size(123, 48);
        }

        private ContextMenuStrip ctlPopupTable_MNU = new ContextMenuStrip();
        private ToolStripMenuItem ctlPopupTableEncryptMNU = new ToolStripMenuItem();
        private ToolStripMenuItem ctlPopupTableDecryptMNU = new ToolStripMenuItem();
        private void DoPopupTableMenu_Init()
        {
            // --- Encrypt menu
            ctlPopupTableEncryptMNU.Name = "ctlPopupTableEncryptMNU";
            ctlPopupTableEncryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupTableEncryptMNU.Text = "Encrypt Table";
            ctlPopupTableEncryptMNU.Click += new System.EventHandler(ctlEncryptTableMNU_Click);
            // --- Decrypt menu
            ctlPopupTableDecryptMNU.Name = "ctlPopupTableDecryptMNU";
            ctlPopupTableDecryptMNU.Size = new System.Drawing.Size(122, 22);
            ctlPopupTableDecryptMNU.Text = "Decrypt Table";
            ctlPopupTableDecryptMNU.Click += new System.EventHandler(ctlDecryptTableMNU_Click);
            // --- now build the popup menu
            ToolStripItem[] mnuOptions = new ToolStripItem[2] 
                                        {   ctlPopupTableEncryptMNU
                                          , ctlPopupTableDecryptMNU 
                                        };
            ctlPopupTable_MNU.Items.AddRange(mnuOptions);
            ctlPopupTable_MNU.Name = "ctlPopupTable_MNU";
            ctlPopupTable_MNU.Size = new System.Drawing.Size(123, 48);
        }

        #endregion //Popup Menus Builder

        #region Popup Menus Event Handler
        private void OnMouseDown_DataGridView(object sender, MouseEventArgs e)
        {
            // If the user right-clicks a cell, store it for use by the shortcut menu.
            if (e.Button == MouseButtons.Right)
            {
                int col;
                int row;
                int X;
                int Y;
                //DataGridViewCell clickedCell;
                DataGridView.HitTestInfo hit = this.ctlTableDGV.HitTest(e.X, e.Y);
                col = hit.ColumnIndex;
                row = hit.RowIndex;
                //select the cell (to remove any ambiguity)
                //clickedCell = this.ctlTableDGV.Rows[row].Cells[col];
                //--- get the X and Y for showing the popup
                X = hit.ColumnX;
                Y = hit.RowY;
                X += this.Location.X;
                Y += this.Location.Y;

                switch (hit.Type)
                {
                    case DataGridViewHitTestType.Cell:
                        this.ctlTableDGV[col, row].Selected = true;
                        this.ctlPopupCell_MNU.Show(X, Y);
                        break;

                    case DataGridViewHitTestType.ColumnHeader:
                        this.ctlTableDGV[col, 0].Selected = true;
                        this.ctlPopupColumn_MNU.Show(X, Y);
                        break;

                    case DataGridViewHitTestType.RowHeader:
                        this.ctlTableDGV[0, row].Selected = true;
                        this.ctlPopupRow_MNU.Show(X, Y);
                        break;

                    case DataGridViewHitTestType.TopLeftHeader:
                        this.ctlTableDGV.SelectAll();
                        this.ctlPopupTable_MNU.Show(X, Y);
                        break;
                }
            }
        }
        #endregion //Popup Menus Event Handler

        #region Printing Event Handlers and Helpers
        private void ctlPrintHowEverythingMNU_Click(object sender, EventArgs e)
        {
            this.ctlPrintHowEverythingMNU.Checked = !this.ctlPrintHowEverythingMNU.Checked;
            this.ctlPrintHowSelectedColumnMNU.Checked = !this.ctlPrintHowEverythingMNU.Checked;
        }

        private void ctlPrintHowSelectedColumnMNU_Click(object sender, EventArgs e)
        {
            this.ctlPrintHowSelectedColumnMNU.Checked = !ctlPrintHowSelectedColumnMNU.Checked;
            this.ctlPrintHowEverythingMNU.Checked = !ctlPrintHowSelectedColumnMNU.Checked;
        }

        private void ctlFilePrintPreviewMNU_Click(object sender, EventArgs e)
        {
            bool bPreview = true;
            bool bSetup = true;
            bool bPrint = true;
            this.DoPrint(bSetup, bPreview, bPrint);
        }

        private void ctlFilePrintMNU_Click(object sender, EventArgs e)
        {
            bool bPreview = false;
            bool bSetup = true;
            bool bPrint = true;
            this.DoPrint(bSetup, bPreview, bPrint);
        }

        private void DoPrint(bool bSetup, bool bPreview, bool bPrint)
        {
            VVX.Print dgvPrint = new Print(this.ctlTableDGV, bSetup, bPreview, bPrint);

            if (dgvPrint != null)
            {
                FileInfo fi = new FileInfo(this.msXmlStoreFile);
                dgvPrint.PrintTitle = fi.Name;

                dgvPrint.PrintHowDGV = Print.HowToPrintDGV.Everything;
                if (this.ctlPrintHowSelectedColumnMNU.Checked)
                    dgvPrint.PrintHowDGV = Print.HowToPrintDGV.SelectedColumns;
                
                dgvPrint.DoPrintDGV();
            }
        }
        #endregion //Printing Event Handlers and Helpers

        #endregion //Popup Menus

        //************************************************************
        #endregion //Event Handlers
    }
}