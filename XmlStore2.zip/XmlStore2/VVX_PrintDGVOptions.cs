using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace VVX
{
    public partial class PrintOptions : Form
    {
        #region Constructors
        public PrintOptions()
        {
            InitializeComponent();
        }
        
        public PrintOptions(List<string> availableFields)
        {
            InitializeComponent();

            foreach (string column in availableFields)
            {
                ctlColumnsToPrintCHKLBX.Items.Add(column, true);
            }
        }
        #endregion //Constructors

        #region Event Handlers
        private void OnLoadForm(object sender, EventArgs e)
        {
            // Initialize some controls
            ctlPrintAllRowsRBTN.Checked = true;
            ctlPrintToFitPageWidthCHK.Checked = true; 
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        #endregion //Event Handlers

        public List<string> GetSelectedColumns()
        {
            List<string> list = new List<string>();
            foreach (object item in ctlColumnsToPrintCHKLBX.CheckedItems)
            {
                list.Add(item.ToString());
            }
            return list;
        }

        #region Properties
        public string PrintTitle
        {
            get { return ctlPrintTitleTBX.Text; }
            set { ctlPrintTitleTBX.Text = value; }
        }

        public bool PrintAllRows
        {
            get { return ctlPrintAllRowsRBTN.Checked; }
        }

        public bool FitToPageWidth
        {
            get { return ctlPrintToFitPageWidthCHK.Checked; }
        }
        #endregion //Properties

    }
}