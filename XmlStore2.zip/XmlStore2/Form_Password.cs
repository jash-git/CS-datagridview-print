using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace XmlStoreClient
{
    /// <summary>
    /// Simple form to obtain a password from a user
    /// </summary>
    public partial class Form_Password : Form
    {
        private string msPassword = "";

        public string Password
        {
            get { return msPassword; }
            set { msPassword = value; }
        }

        public Form_Password()
        {
            InitializeComponent();
            this.DialogResult = DialogResult.Cancel;
            this.ctlPasswordTBX.Text = this.msPassword;
        }

        private void ctlApplyBTN_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.msPassword = this.ctlPasswordTBX.Text;
            this.Close();
        }

        private void ctlCancelBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}