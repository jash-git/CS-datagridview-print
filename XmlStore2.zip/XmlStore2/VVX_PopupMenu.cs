using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace VVX
{
    class PopupMenu
    {
        private ContextMenuStrip mnuPopup = new ContextMenuStrip();
        private ToolStripMenuItem mnuOption1 = new ToolStripMenuItem(); 
        private ToolStripMenuItem mnuOption2 = new ToolStripMenuItem();

        private int nOptionSelected = 0;

        public int DoShowContextMenu(int X, int Y)
        {
            foo();

            mnuPopup.Show(X, Y);

            return nOptionSelected;
        }

        private void foo()
        {

            // 
            // includeToolStripMenuItem
            // 
            mnuOption1.Name = "ctlEncryptCell";
            mnuOption1.Size = new System.Drawing.Size(122, 22);
            mnuOption1.Text = "Decrypt";
            mnuOption1.Click += new System.EventHandler(OnClickOption1);
            // 
            // excludeToolStripMenuItem
            // 
            mnuOption2.Name = "ctlDecryptCell";
            mnuOption2.Size = new System.Drawing.Size(122, 22);
            mnuOption2.Text = "Decrypt";
            mnuOption2.Click += new System.EventHandler(OnClickOption2);

            // 
            // mnuTable
            // 
            ToolStripItem[] mnuOptions = new ToolStripItem [2]{mnuOption1,mnuOption2};
            //mnuPopup.Items.AddRange(new System.Windows.Forms.ToolStripItem[] 
            //                            {mnuOption1,mnuOption2});
            mnuPopup.Items.AddRange(mnuOptions);
            mnuPopup.Name = "mnuTable";
            mnuPopup.Size = new System.Drawing.Size(123, 48);
        }

        //-----------------------------------------------------------------------------------
        private void OnClickOption1(object sender, EventArgs e)
        {
            nOptionSelected = 1;
            MsgBox.Info("Option 1 selected");
        }

        //-----------------------------------------------------------------------------------
        private void OnClickOption2(object sender, EventArgs e)
        {
            nOptionSelected = 1;
            MsgBox.Info("Option 2 selected");
        }


        private ContextMenuStrip CreateCellMenu()
        {
		    ContextMenuStrip cms = new ContextMenuStrip();
            if(cms != null)
            {

                //cms.Items.Add(new ToolStripMenuItem("Cut", this.Resources.Images.Cut, OnCutMenuItemClick()))
                //cms.Items.Add(new ToolStripMenuItem("Copy", My.Resources.Images.Copy, AddressOf OnCopyMenuItemClick))
                //cms.Items.Add(new ToolStripMenuItem("Paste", My.Resources.Images.Paste, AddressOf OnPasteMenuItemClick))
                //cms.Items.Add(new ToolStripSeparator())
                //cms.Items.Add(new ToolStripMenuItem("Fill Down", My.Resources.Images.FillDownHS, AddressOf OnFillDownMenuItemClick))
                //cms.Items.Add(new ToolStripMenuItem("Fill Right", My.Resources.Images.FillRightHS, AddressOf OnFillRightMenuItemClick))
                //cms.Items.Add(new ToolStripSeparator())
                //cms.Items.Add(new ToolStripMenuItem("Clear", DirectCast(Nothing, Image), AddressOf OnClearMenuItemClick))

                cms.Items.Add("Cut");
            }
		return cms;
        }

    }
}
