using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;

// ************************************************************************************************
// This is taken from (as of Mat 14, 2007)
// "A component that prints any control, including ListViews, TreeViews, DataGridViews, and Forms"
// By Nader Elshehabi. http://www.codeproject.com/csharp/ControlPrint.asp
// 
// ************************************************************************************************


namespace VVX
{
    public partial class ControlPrint : PrintDocument
    {
        private Control mControl;

        private bool mbStretch;
        private int mWidth;
        private int mHeight;
        private int mInBetween;
        private int mPrintedHeight;

        private bool mbOkToResize = true;


        /// <summary>
        /// Set true to stretch the control to fill a single printed page
        /// </summary>
        public bool StretchControl
        {
            set { mbStretch = value; }
            get { return mbStretch; }
        }

        /// <summary>
        /// The width of the control to print. You can change this value if the automatically 
        /// calculated width does not fit all the elements of the control
        /// </summary>
        public int PrintWidth
        {
            set { mWidth = value; }
            get { return mWidth; }
        }
        /// <summary>
        /// The height of the control to print. You can change this value if the automatically
        /// calculated height does not fit all the elements of the control
        /// </summary>
        public int PrintHeight
        {
            set { mHeight = value; }
            get { return mHeight; }
        }

        /// <summary>
        /// The area to be reprinted between pages if there are more than one
        /// pages to be printed, to prevent data loss
        /// </summary>
        public int RepeatArea
        {
            get { return mInBetween; }
            set { mInBetween = value; }
        }
        
        /// <summary>
        /// Default constructor
        /// </summary>
        public ControlPrint()
        {
            InitializeComponent();
            mControl = new Control();
            mbStretch = false;
            mWidth = mControl.Width;
            mHeight = mControl.Height;
            mInBetween = 10;
        }

        /// <summary>
        /// Intialize the component with the selected control
        /// </summary>
        /// <param name="controlToPrint">The control to be printed; can be an entire form</param>
        public ControlPrint(Control controlToPrint)
        {
            InitializeComponent();
            SetControl(controlToPrint);
            mbStretch = false;
            mInBetween = 10;
        }

        /// <summary>
        /// Initialize the component with the selected control specifying
        /// whether to stretch or not
        /// </summary>
        /// <param name="print">The control to be printed</param>
        /// <param name="Stretch">Set true to stretch the control to fill a single printed page</param>
        public ControlPrint(Control print, bool Str)
        {
            InitializeComponent();
            SetControl(print);
            mbStretch = Str;
            mInBetween = 10;
        }

        /// <summary>
        /// Initialize the component with the selected control specifying
        /// specific width and height
        /// </summary>
        /// <param name="print">The control to be printed</param>
        /// <param name="Width">Printed width</param>
        /// <param name="Height">Printed height</param>
        public ControlPrint(Control print, int Width, int Height)
        {
            InitializeComponent();
            SetControl(print);
            mbStretch = false;
            mWidth = Width;
            mHeight = Height;
            mInBetween = 10;
        }

        /// <summary>
        /// Initialize the component with the selected control specifying
        /// specific width and height
        /// </summary>
        /// <param name="print">The control to be printed</param>
        /// <param name="Width">Printed width</param>
        /// <param name="Height">Printed height</param>
        /// <param name="NotOkToSize">Use exactly this size</param>
        public ControlPrint(Control print, int Width, int Height, bool NotOkToSize)
        {
            InitializeComponent();
            SetControl(print);
            mbStretch = false;
            mWidth = Width;
            mHeight = Height;
            mInBetween = 10;
            this.mbOkToResize = !NotOkToSize;
        }
        /// <summary>
        /// Intialize the component with a specific container, Insignificant
        /// </summary>
        /// <param name="container"></param>
        private ControlPrint(IContainer container)
        {
            container.Add(this);
            InitializeComponent();
            mControl = new Control();
            mbStretch = false;
            mInBetween = 10;
        }

        /// <summary>
        /// Set the control to be printed
        /// </summary>
        /// <param name="print">The control you wish to print</param>
        public void SetControl(Control print)
        {
            mControl = print;
            Size NewSize = mControl.GetPreferredSize(Size.Empty);
            mWidth = NewSize.Width;
            mHeight = NewSize.Height;
            if ((mWidth == 0) || (mHeight == 0))
            {
                mWidth = mControl.Width;
                mHeight = mControl.Height;
                this.mbOkToResize = false;
            }
            mPrintedHeight = 0;
        }

        /// <summary>
        /// Set the control with a specified height & width
        /// </summary>
        /// <param name="print">The control to be printed</param>
        /// <param name="Width">Control's width</param>
        /// <param name="Height">Control's height</param>
        public void SetControl(Control print, int Width, int Height)
        {
            mControl = print;
            mWidth = Width;
            mHeight = Height;
            mPrintedHeight = 0;
        }

        private void ControlPrint_PrintPage(object sender, PrintPageEventArgs e)
        {
            //We get the old status of the control
            Size NewSize = new Size(mWidth, mHeight);
            DockStyle OldDock = mControl.Dock;
            Size OldSize = new Size(mControl.Width, mControl.Height);
            Control parent = mControl;
            List<Control> Parents = new List<Control>();
            List<Size> OldSizes = new List<Size>();
            
            //enumerate the parents
            while (parent.Parent != null)
            {
                Parents.Add(parent.Parent);
                OldSizes.Add(parent.Parent.Size);
                parent = parent.Parent;
            }
            
            //Change the size of the control to fully display it and get rid of scrollbars
            mControl.Dock = DockStyle.None;
            mControl.Size = NewSize;

            //Make sure that the size changes otherwise resize the parents
            if (this.mbOkToResize)
            {
                while (mControl.Size == OldSize)
                {
                    foreach (Control ctl in Parents)
                    {
                        ctl.Size = new Size(ctl.Width + 100, ctl.Height + 100);
                    }
                    mControl.Size = NewSize;
                }
            }
            
            //print dimentions will be according to page size and margins
            int printwidth = mWidth;
            int printheight = mHeight;

            //change the width to fit the paper, and change the height to maintain the ratio
            if (printwidth > e.MarginBounds.Width)
            {
                printheight = (int)(((float)e.MarginBounds.Width / (float)printwidth) * printheight);
                printwidth = e.MarginBounds.Width;
            }

            //if too long, we will need more papers
            if (printheight - mPrintedHeight > e.MarginBounds.Height && !mbStretch)
                e.HasMorePages = true;
            else
                e.HasMorePages = false;
            

            GraphicsUnit gp = GraphicsUnit.Point;
            Bitmap bmp = new Bitmap(mWidth, mHeight);
            
            //Good, now we can draw
            mControl.DrawToBitmap(bmp, new Rectangle(0, 0, mWidth, mHeight));
            
            //Will we stretch the image?
            if (mbStretch)
            {
                e.Graphics.DrawImage(bmp, e.MarginBounds, bmp.GetBounds(ref gp), gp);
                e.HasMorePages = false;
            }
            else
            {
                //If not stretched then make sure to print the area of the current page only
                float ScaleF = (float)mHeight / (float)printheight;
                printheight -= mPrintedHeight;
                if (printheight > e.MarginBounds.Height)
                    printheight = e.MarginBounds.Height;
                Rectangle rect = new Rectangle(0, (int)(mPrintedHeight * ScaleF), bmp.Width, (int)(printheight * ScaleF));
                Bitmap b2 = bmp.Clone(rect, System.Drawing.Imaging.PixelFormat.DontCare);
                e.Graphics.DrawImage(b2, new Rectangle((e.PageBounds.Width/2) - (printwidth/2), e.MarginBounds.Top, printwidth, printheight));
            }
            if (e.HasMorePages)
            {
                //Change the printed height, and don't forget the RepeatArea
                mPrintedHeight += e.MarginBounds.Height - mInBetween;
            }
            else
                mPrintedHeight = 0;
            //Restore the control's state
            for (int i = 0; i < Parents.Count; i++)
                Parents[i].Size = OldSizes[i];
            mControl.Size = new Size(OldSize.Width, OldSize.Height);
            mControl.Dock = OldDock;
        }

        /// <summary>
        /// Draw the control fully to a bitmap & return it
        /// </summary>
        /// <returns></returns>
        public Bitmap GetBitmap()
        {
            //Get old states
            Size NewSize = new Size(mWidth, mHeight);
            DockStyle OldDock = mControl.Dock;
            Size OldSize = new Size(mControl.Width, mControl.Height);
            Control parent = mControl;
            List<Control> Parents = new List<Control>();
            List<Size> OldSizes = new List<Size>();

            while (parent.Parent != null)
            {
                Parents.Add(parent.Parent);
                OldSizes.Add(parent.Parent.Size);
                parent = parent.Parent;
            }
            
            mControl.Dock = DockStyle.None;
            mControl.Size = NewSize;
            while (mControl.Size == OldSize)
            {
                foreach (Control c in Parents)
                {
                    c.Size = new Size(c.Width + 100, c.Height + 100);
                }
                mControl.Size = NewSize;
            }
            Bitmap b = new Bitmap(mWidth, mHeight);
            //Draw
            mControl.DrawToBitmap(b, new Rectangle(0, 0, mWidth, mHeight));
            //Restore states
            for (int i = 0; i < Parents.Count; i++)
                Parents[i].Size = OldSizes[i];
            mControl.Size = new Size(OldSize.Width, OldSize.Height);
            mControl.Dock = OldDock;
            return b;
        }

        private List<TreeNode> Nodes; // All enumerated nodes are here
        private void EnumNodes(TreeNode TN)
        {
            if (!Nodes.Contains(TN) && (TN.Parent == null || (TN.Parent != null && TN.Parent.IsExpanded)))
                Nodes.Add(TN);
            //Enum all subnodes of the current node
            foreach (TreeNode R in TN.Nodes)
                EnumNodes(R);
        }
        
        /// <summary>
        /// Return the best size that fits the control
        /// </summary>
        /// <returns></returns>
        public Size CalculateSize()
        {
            //Identify the control's type
            if (mControl.GetType().AssemblyQualifiedName.IndexOf("TreeView") >= 0)
            {
                if (((TreeView)mControl).Nodes.Count == 0)
                {
                    //if no elemts return 1X1 to avoid exceptions
                    return new Size(1, 1);
                }
                else
                {
                    int TempW = 0, TempH = 0;
                    Nodes = new List<TreeNode>();
                    foreach (TreeNode T in ((TreeView)mControl).Nodes)
                        EnumNodes(T);
                    foreach (TreeNode N in Nodes)
                    {
                        if (TempW < N.Bounds.Right)
                            TempW = N.Bounds.Right;
                    }
                    TempH = Nodes.Count * ((TreeView)mControl).ItemHeight;
                    return new Size(TempW + 30, TempH + 30);
                }
            }
            else if (mControl.GetType().AssemblyQualifiedName.IndexOf("ListView") >= 0)
            {
                if (((ListView)mControl).Items.Count > 0)
                {
                    //This will work if the listview is in details mode
                    ((ListView)mControl).Items[0].EnsureVisible();
                    int tempwidth = ((ListView)mControl).Items[0].Bounds.Width;
                    int tempheight = ((ListView)mControl).Items[((ListView)mControl).Items.Count - 1].Bounds.Bottom;
                    //This is for other modes
                    foreach (ListViewItem i in ((ListView)mControl).Items)
                    {
                        if (tempwidth < i.Bounds.Right)
                            tempwidth = i.Bounds.Right;
                        if (tempheight < i.Bounds.Bottom)
                            tempheight = i.Bounds.Bottom;
                    }
                    return new Size(tempwidth + 30, tempheight + 30);
                }
                else
                    return new Size(1, 1);
            }
            else if (mControl.Controls.Count > 0)
            {
                //Just in case the form didn't calculate its PreferredSize properly
                int tempwidth = 1;
                int tempheight = 1;
                foreach (Control c in mControl.Controls)
                {
                    if (c.Bounds.Right > tempwidth)
                        tempwidth = c.Bounds.Right;
                    if (c.Bounds.Bottom > tempheight)
                        tempheight = c.Bounds.Bottom;
                }
                return new Size(tempwidth, tempheight);
            }
            else
            {
                return new Size(mControl.PreferredSize.Width, mControl.PreferredSize.Height);
            }

            //return Size.Empty;
        }

        /// <summary>
        /// Apply the best size that fits the control
        /// </summary>
        public void ApplyBestSize()
        {
            Size temp = CalculateSize();
            mWidth = temp.Width;
            mHeight = temp.Height;
        }
    }
}
