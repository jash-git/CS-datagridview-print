namespace XmlStoreClient
{
    partial class Form_Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctlPasswordTBX = new System.Windows.Forms.TextBox();
            this.ctlPasswordLBL = new System.Windows.Forms.Label();
            this.ctlApplyBTN = new System.Windows.Forms.Button();
            this.ctlCancelBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ctlPasswordTBX
            // 
            this.ctlPasswordTBX.Location = new System.Drawing.Point(16, 38);
            this.ctlPasswordTBX.Name = "ctlPasswordTBX";
            this.ctlPasswordTBX.PasswordChar = '*';
            this.ctlPasswordTBX.Size = new System.Drawing.Size(190, 20);
            this.ctlPasswordTBX.TabIndex = 0;
            // 
            // ctlPasswordLBL
            // 
            this.ctlPasswordLBL.AutoSize = true;
            this.ctlPasswordLBL.Location = new System.Drawing.Point(13, 12);
            this.ctlPasswordLBL.Name = "ctlPasswordLBL";
            this.ctlPasswordLBL.Size = new System.Drawing.Size(193, 13);
            this.ctlPasswordLBL.TabIndex = 1;
            this.ctlPasswordLBL.Text = "Password for encryption and decryption";
            // 
            // ctlApplyBTN
            // 
            this.ctlApplyBTN.Location = new System.Drawing.Point(16, 80);
            this.ctlApplyBTN.Name = "ctlApplyBTN";
            this.ctlApplyBTN.Size = new System.Drawing.Size(75, 23);
            this.ctlApplyBTN.TabIndex = 2;
            this.ctlApplyBTN.Text = "Apply";
            this.ctlApplyBTN.UseVisualStyleBackColor = true;
            this.ctlApplyBTN.Click += new System.EventHandler(this.ctlApplyBTN_Click);
            // 
            // ctlCancelBTN
            // 
            this.ctlCancelBTN.Location = new System.Drawing.Point(131, 80);
            this.ctlCancelBTN.Name = "ctlCancelBTN";
            this.ctlCancelBTN.Size = new System.Drawing.Size(75, 23);
            this.ctlCancelBTN.TabIndex = 3;
            this.ctlCancelBTN.Text = "Cancel";
            this.ctlCancelBTN.UseVisualStyleBackColor = true;
            this.ctlCancelBTN.Click += new System.EventHandler(this.ctlCancelBTN_Click);
            // 
            // Form_Password
            // 
            this.AcceptButton = this.ctlApplyBTN;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.ctlCancelBTN;
            this.ClientSize = new System.Drawing.Size(219, 115);
            this.Controls.Add(this.ctlCancelBTN);
            this.Controls.Add(this.ctlApplyBTN);
            this.Controls.Add(this.ctlPasswordLBL);
            this.Controls.Add(this.ctlPasswordTBX);
            this.Name = "Form_Password";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form_Password";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ctlPasswordTBX;
        private System.Windows.Forms.Label ctlPasswordLBL;
        private System.Windows.Forms.Button ctlApplyBTN;
        private System.Windows.Forms.Button ctlCancelBTN;
    }
}