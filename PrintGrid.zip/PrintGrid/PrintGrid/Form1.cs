using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PrintGrid
{
    public partial class Form1 : Form
    {
        Bitmap bm;
        int i = 0;
        string[] names=new string[] {"Amey","vijay","Ranjit","Bharat","saba"};
        public Form1()
        {
            InitializeComponent();
            FillDataGridView();
        }

        private void FillDataGridView()
        {
            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add("Id");
            dt.Columns.Add("Name");
            for (int i = 0; i < 100 ; i++)
            {
                dr = dt.NewRow();
                dr["Id"] = i + 1;
                dr["Name"] = names[i % 5];
                dt.Rows.Add(dr);
            }
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
            //if (printDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    printDialog1.Document = printDocument1;

            //}

        }

        private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            
            int width = 0;
            int height = 0;
            int x = 0;
            int y = 0;
            int rowheight = 0;
            int columnwidth = 0;

            StringFormat str=new StringFormat();
            str.Alignment=StringAlignment.Near;
            str.LineAlignment=StringAlignment.Center;
            str.Trimming=StringTrimming.EllipsisCharacter;
            Pen p=new Pen(Color.Black,2.5f);
            //e.Graphics.DrawRectangle(p,dataGridView1.Bounds);
            
            //printPreviewDialog1.Document=printDocument1;
            //e.Graphics.DrawString("Hi this a test print", new Font(Font.SystemFontName,10.5f), Brushes.Black, new PointF(250.0f, 250.0f));
            //e.Graphics.DrawImage((Image)bm,new Point(10,10));

            #region Draw Column 1 

            e.Graphics.FillRectangle(Brushes.LightGray, new Rectangle(100, 100, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height));
            e.Graphics.DrawRectangle(Pens.Black, 100, 100, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height);
            e.Graphics.DrawString(dataGridView1.Columns[0].HeaderText, dataGridView1.Font, Brushes.Black, new RectangleF(100, 100, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height), str);

            #endregion

            #region Draw column 2 

            e.Graphics.FillRectangle(Brushes.LightGray, new Rectangle(100 + dataGridView1.Columns[0].Width, 100 , dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height));
            e.Graphics.DrawRectangle(Pens.Black, 100 + dataGridView1.Columns[0].Width, 100, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height);
            e.Graphics.DrawString(dataGridView1.Columns[1].HeaderText, dataGridView1.Font, Brushes.Black, new RectangleF(100 + dataGridView1.Columns[0].Width, 100, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height), str);

            width = 100 + dataGridView1.Columns[0].Width;
            height = 100;
            //variable i is declared at class level to preserve the value of i if e.hasmorepages is true
            while (i < dataGridView1.Rows.Count)
            {
                if (height > e.MarginBounds.Height)
                {
                    height = 100;
                    width = 100;
                    e.HasMorePages = true;
                    return;
                }

                height += dataGridView1.Rows[i].Height;
                e.Graphics.DrawRectangle(Pens.Black, 100, height, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height);
                e.Graphics.DrawString(dataGridView1.Rows[i].Cells[0].FormattedValue.ToString(), dataGridView1.Font, Brushes.Black, new RectangleF(100, height, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height), str);

                e.Graphics.DrawRectangle(Pens.Black, 100 + dataGridView1.Columns[0].Width, height, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height);
                e.Graphics.DrawString(dataGridView1.Rows[i].Cells[1].Value.ToString(), dataGridView1.Font, Brushes.Black, new RectangleF(100 + dataGridView1.Columns[0].Width, height, dataGridView1.Columns[0].Width, dataGridView1.Rows[0].Height), str);

                width += dataGridView1.Columns[0].Width;
                i++;
            }

            #endregion
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bm = new Bitmap(dataGridView1.ClientRectangle.Width, dataGridView1.ClientRectangle.Height);
            dataGridView1.DrawToBitmap(bm, dataGridView1.ClientRectangle);
            bm.Save(@"C:\datagrid", System.Drawing.Imaging.ImageFormat.Jpeg);
            bm = null;
            bm = new Bitmap(button1.ClientRectangle.Width, button1.ClientRectangle.Height);
            button1.DrawToBitmap(bm, button1.ClientRectangle);
        }
    }
}